CRIMSON ORBIT - MUSICAL BAND (High-Hertz Acoustic Edition)
============================================================
Included Files:
- new2.flp       : Bootable 1.44 MB Floppy Image (Concert Piano, Singing Guitar, LFSR Drums)
- loader.bin     : 512-byte MBR boot sector with 0x55AA signature
- kernel.bin     : Flat 16-bit binary loaded at 1000h:0000h

How to Run:
1. In VMware Workstation:
   - Create/open virtual machine
   - In Floppy Drive settings, connect 'new2.flp'
   - Power On virtual machine
2. In emu8086:
   - Open Source/kernel.asm -> click Emulate -> click Run
============================================================
